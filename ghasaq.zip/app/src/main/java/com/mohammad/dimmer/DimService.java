package com.mohammad.dimmer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;

/** يرسم طبقة سوداء شفافة فوق كل التطبيقات لتقليل الإضاءة */
public class DimService extends Service implements SharedPreferences.OnSharedPreferenceChangeListener {
    SharedPreferences sp;
    WindowManager wm;
    View dim;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("dimmer", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startFg();
        sp.registerOnSharedPreferenceChangeListener(this);
        refresh();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        refresh();
        return START_STICKY;
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences s, String key) {
        if ("level".equals(key) || "mode".equals(key)) refresh();
    }

    void startFg() {
        String ch = "dim";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(ch, "التعتيم",
                    NotificationManager.IMPORTANCE_MIN));
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, ch) : new Notification.Builder(this);
        b.setContentTitle("انوصة").setContentText("التعتيم يعمل")
                .setSmallIcon(android.R.drawable.ic_menu_view);
        startForeground(1, b.build());
    }

    void refresh() {
        String mode = sp.getString("mode", "system");
        int lvl = sp.getInt("level", 100);
        boolean can = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        if (!"overlay".equals(mode) || lvl >= 100 || !can) {
            removeDim();
            stopForeground(true);
            stopSelf();
            return;
        }
        setDim((100 - lvl) / 99f * 0.85f);
    }

    void setDim(float a) {
        try {
            int color = Color.argb((int) (a * 255), 0, 0, 0);
            if (dim == null) {
                dim = new View(this);
                dim.setBackgroundColor(color);
                int type = Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        PixelFormat.TRANSLUCENT);
                wm.addView(dim, lp);
            } else {
                dim.setBackgroundColor(color);
            }
        } catch (Exception ignored) { }
    }

    void removeDim() {
        try {
            if (dim != null) {
                wm.removeView(dim);
                dim = null;
            }
        } catch (Exception ignored) { }
    }

    @Override
    public void onDestroy() {
        removeDim();
        try {
            sp.unregisterOnSharedPreferenceChangeListener(this);
        } catch (Exception ignored) { }
        super.onDestroy();
    }
}
