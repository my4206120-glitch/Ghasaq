package com.mohammad.dimmer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

/** يعيد التعتيم تلقائياً عند تشغيل الشاشة إن فعّلت الخيار */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            SharedPreferences sp = c.getSharedPreferences("dimmer", Context.MODE_PRIVATE);
            if (!sp.getBoolean("boot", false)) return;
            int lvl = sp.getInt("level", 100);
            if ("overlay".equals(sp.getString("mode", "system"))) {
                if (lvl >= 100) return;
                Intent s = new Intent(c, DimService.class);
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s);
                else c.startService(s);
            } else if (Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(c)) {
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS,
                        Math.max(1, Math.round(lvl * 255f / 100f)));
            }
        } catch (Exception ignored) { }
    }
}
