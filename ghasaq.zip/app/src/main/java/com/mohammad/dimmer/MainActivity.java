package com.mohammad.dimmer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    interface OnLevel { void on(int level); }

    /** شريط أفقي يُسحب باللمس: من 1 إلى 100 */
    static class SliderView extends View {
        int level = 100;
        OnLevel cb;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final float d;

        SliderView(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        void setLevel(int l) {
            level = Math.max(1, Math.min(100, l));
            invalidate();
        }

        float pad() { return 28 * d; }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), (int) (90 * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float pad = pad(), cy = h / 2f, th = 18 * d;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x33FFFFFF);
            c.drawRoundRect(new RectF(pad, cy - th / 2, w - pad, cy + th / 2), th / 2, th / 2, p);
            float x = pad + (w - 2 * pad) * (level - 1) / 99f;
            p.setColor(0xFFFFC845);
            c.drawRoundRect(new RectF(pad, cy - th / 2, x, cy + th / 2), th / 2, th / 2, p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(x, cy, 26 * d, p);
            p.setColor(0xFFFFC845);
            c.drawCircle(x, cy, 12 * d, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            int a = ev.getAction();
            if (a == MotionEvent.ACTION_DOWN && getParent() != null) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_UP) {
                float pad = pad();
                float f = (ev.getX() - pad) / (getWidth() - 2 * pad);
                int l = Math.round(f * 99) + 1;
                l = Math.max(1, Math.min(100, l));
                level = l;
                invalidate();
                if (cb != null) cb.on(l);
                return true;
            }
            return super.onTouchEvent(ev);
        }
    }

    SharedPreferences sp;
    float d;
    SliderView slider;
    TextView pct, permBtn, chipSys, chipOv;
    Handler h = new Handler(Looper.getMainLooper());

    int dp(int v) { return (int) (v * d + 0.5f); }

    String mode() { return sp.getString("mode", "system"); }

    boolean canWrite() { return Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(this); }

    boolean canOverlay() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("dimmer", MODE_PRIVATE);
        d = getResources().getDisplayMetrics().density;

        int level = sp.getInt("level", -1);
        if (level < 1) {
            level = 100;
            try {
                level = Math.round(Settings.System.getInt(getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS) * 100f / 255f);
            } catch (Exception ignored) { }
            level = Math.max(1, Math.min(100, level));
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(28), dp(22), dp(28), dp(22));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF0A1020, 0xFF16203A}));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        try {
            logo.setImageDrawable(getPackageManager().getApplicationIcon(getPackageName()));
        } catch (Exception ignored) { }
        head.addView(logo, new LinearLayout.LayoutParams(dp(58), dp(58)));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setPadding(dp(14), 0, dp(14), 0);
        TextView title = new TextView(this);
        title.setText("انوصة");
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFFF4EFE6);
        TextView sub = new TextView(this);
        sub.setText("تحكّم بسطوع الشاشة");
        sub.setTextSize(15);
        sub.setTextColor(0x99F4EFE6);
        names.addView(title);
        names.addView(sub);
        head.addView(names);
        root.addView(head, new LinearLayout.LayoutParams(-2, -2));

        root.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1));

        pct = new TextView(this);
        pct.setTextSize(76);
        pct.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        pct.setTextColor(0xFFFFFFFF);
        pct.setGravity(Gravity.CENTER);
        root.addView(pct);

        LinearLayout row = new LinearLayout(this);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView minus = roundBtn("−");
        TextView plus = roundBtn("+");
        slider = new SliderView(this);
        slider.cb = l -> applyLevel(l);
        row.addView(minus, new LinearLayout.LayoutParams(dp(68), dp(68)));
        row.addView(slider, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(plus, new LinearLayout.LayoutParams(dp(68), dp(68)));
        root.addView(row, new LinearLayout.LayoutParams(-1, -2));
        bindRepeat(minus, -1);
        bindRepeat(plus, 1);

        LinearLayout chips = new LinearLayout(this);
        chips.setGravity(Gravity.CENTER);
        chips.setPadding(0, dp(18), 0, dp(8));
        chipSys = chip("سطوع النظام");
        chipOv = chip("تعتيم فوق الشاشة");
        chipSys.setOnClickListener(v -> setMode("system"));
        chipOv.setOnClickListener(v -> setMode("overlay"));
        chips.addView(chipSys);
        chips.addView(chipOv);
        root.addView(chips);

        permBtn = new TextView(this);
        permBtn.setTextSize(17);
        permBtn.setTextColor(0xFF2A1A00);
        permBtn.setGravity(Gravity.CENTER);
        permBtn.setPadding(dp(22), dp(12), dp(22), dp(12));
        permBtn.setBackground(rounded(0xFFFFC845, dp(24)));
        permBtn.setOnClickListener(v -> askPermission());
        root.addView(permBtn, new LinearLayout.LayoutParams(-2, -2));

        Switch sw = new Switch(this);
        sw.setText("تطبيق التعتيم تلقائياً عند تشغيل الشاشة");
        sw.setTextColor(0xCCF4EFE6);
        sw.setTextSize(15);
        sw.setPadding(0, dp(14), 0, 0);
        sw.setChecked(sp.getBoolean("boot", false));
        sw.setOnCheckedChangeListener((bv, on) -> sp.edit().putBoolean("boot", on).apply());
        root.addView(sw, new LinearLayout.LayoutParams(-2, -2));

        TextView tip = new TextView(this);
        tip.setText("إن لم تتغير إضاءة الشاشة فعلياً في وضع «سطوع النظام» فاختر «تعتيم فوق الشاشة».");
        tip.setTextSize(13);
        tip.setTextColor(0x88F4EFE6);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(12), 0, 0);
        root.addView(tip);

        root.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        slider.setLevel(level);
        show(level);
        styleChips();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePerm();
        applyLevel(slider.level);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
            step(-1);
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
            step(1);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    GradientDrawable rounded(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(r);
        return g;
    }

    TextView roundBtn(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(34);
        v.setTextColor(0xFFFFFFFF);
        v.setGravity(Gravity.CENTER);
        v.setBackground(rounded(0x33FFFFFF, dp(34)));
        return v;
    }

    TextView chip(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(16);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(20), dp(10), dp(20), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(6), 0, dp(6), 0);
        v.setLayoutParams(lp);
        return v;
    }

    void styleChips() {
        boolean sys = "system".equals(mode());
        chipSys.setBackground(rounded(sys ? 0xFFFFC845 : 0x22FFFFFF, dp(22)));
        chipSys.setTextColor(sys ? 0xFF2A1A00 : 0xCCF4EFE6);
        chipOv.setBackground(rounded(sys ? 0x22FFFFFF : 0xFFFFC845, dp(22)));
        chipOv.setTextColor(sys ? 0xCCF4EFE6 : 0xFF2A1A00);
    }

    void bindRepeat(final View btn, final int delta) {
        final Runnable[] rep = new Runnable[1];
        rep[0] = () -> {
            step(delta);
            h.postDelayed(rep[0], 70);
        };
        btn.setOnTouchListener((v, ev) -> {
            int a = ev.getAction();
            if (a == MotionEvent.ACTION_DOWN) {
                step(delta);
                h.postDelayed(rep[0], 400);
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                h.removeCallbacks(rep[0]);
            }
            return true;
        });
    }

    void step(int delta) {
        int l = Math.max(1, Math.min(100, slider.level + delta));
        slider.setLevel(l);
        applyLevel(l);
    }

    void show(int l) {
        pct.setText(l + "%");
    }

    void startDim() {
        Intent s = new Intent(this, DimService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
        else startService(s);
    }

    void putSystem(int l) {
        try {
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS,
                    Math.max(1, Math.round(l * 255f / 100f)));
        } catch (Exception ignored) { }
    }

    void applyLevel(int l) {
        if (l < 1) l = 1;
        if (l > 100) l = 100;
        sp.edit().putInt("level", l).apply();
        show(l);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        if ("system".equals(mode())) {
            if (canWrite()) putSystem(l);
            lp.screenBrightness = l / 100f;
        } else {
            lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
            if (canOverlay() && l < 100) startDim();
        }
        getWindow().setAttributes(lp);
    }

    void setMode(String m) {
        if (m.equals(mode())) return;
        sp.edit().putString("mode", m).apply();
        if ("overlay".equals(m)) {
            if (canWrite()) putSystem(100);
        } else {
            stopService(new Intent(this, DimService.class));
        }
        styleChips();
        updatePerm();
        applyLevel(slider.level);
    }

    void updatePerm() {
        boolean sys = "system".equals(mode());
        boolean need = sys ? !canWrite() : !canOverlay();
        permBtn.setVisibility(need ? View.VISIBLE : View.GONE);
        permBtn.setText(sys ? "السماح بتعديل سطوع النظام" : "السماح بالعرض فوق التطبيقات");
    }

    void askPermission() {
        try {
            if ("system".equals(mode())) {
                startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            } else {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        } catch (Exception e) {
            Toast.makeText(this, "الشاشة لا تدعم هذا الإذن", Toast.LENGTH_LONG).show();
        }
    }
}
